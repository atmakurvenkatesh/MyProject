package com.cognizant.truyum.dao;

import java.sql.*;
import java.util.*;
import com.cognizant.truyum.model.*;

public class CartDaoSqlImpl {

	public static boolean check(String s){
		if(s.equals("Yes"))
			return true;
		return false;
	}

	public void addCartItem(long userId,long menuItemId){
		try{
			Connection con=ConnectionHandler.getConnection();
			String insertCart="insert into cart values(?,?)";
			PreparedStatement ps=con.prepareStatement(insertCart);
			ps.setInt(1, (int)userId);
			ps.setInt(2, (int)menuItemId);
			ps.executeUpdate();		
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

	public List<MenuItem> getAllCartItems(long userId){

		try{
			List<MenuItem> l=new ArrayList<MenuItem>();
			Connection con=ConnectionHandler.getConnection();
			float total=0;
			Cart c=new Cart(l,total);
			String selectCart="select * from user inner join cart  inner join menu_item on (ct_us_id=us_id and ct_pr_id=me_id) where us_id=?";
			PreparedStatement ps=con.prepareStatement(selectCart);
			ps.setInt(1, (int)userId);			
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				MenuItem m=new MenuItem(rs.getLong(5),rs.getString(6),rs.getFloat(7),check(rs.getString(7)),rs.getDate(9),rs.getString(10),check(rs.getString(11)));
				total+=rs.getFloat(7);
				l.add(m);
			}
			c.setMenuItemList(l);
			c.setTotal(total);
			return l;
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
		
		
	}

	public void removeCartItem(long userId,long menuItemId){
		try{
			Connection con=ConnectionHandler.getConnection();
			String s="delete from cart where ct_us_id=? and ct_pr_id=?";
			PreparedStatement ps=con.prepareStatement(s);
			ps.setInt(1, (int)userId);
			ps.setInt(2, (int)menuItemId);
			ps.executeUpdate();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
}
