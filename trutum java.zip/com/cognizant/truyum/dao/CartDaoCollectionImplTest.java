package com.cognizant.truyum.dao;

import com.cognizant.truyum.model.*;
import java.util.*;

public class CartDaoCollectionImplTest {
	
	static CartDao cartDao=new CartDaoCollectionImpl();
	public static void main(String[] args) {
		
		testAddCartItem();
		testGetAllCartItems();
		testRemoveCartItem();
		testGetAllCartItems();
		
	}
	
	public static void testAddCartItem(){
		//CartDao cartDao=new CartDaoCollectionImpl();
		cartDao.addCartItem(1, 1);
		cartDao.addCartItem(1, 2);
		cartDao.addCartItem(1, 3);
		cartDao.addCartItem(2, 3);		
	}
	
	public static void testGetAllCartItems(){
		try{
			//CartDao cartDao=new CartDaoCollectionImpl();		
			List<MenuItem> m=new ArrayList<MenuItem>();
			m=cartDao.getAllCartItems(2);
			for(MenuItem i:m)
				System.out.println(i);	
			System.out.println();
		}
		catch(CartEmptyException e){
			System.out.println("Empty Cart");
		}
	}
	public static void testRemoveCartItem(){
		cartDao.removeCartItem(2 , 2);		
	}
	

}
