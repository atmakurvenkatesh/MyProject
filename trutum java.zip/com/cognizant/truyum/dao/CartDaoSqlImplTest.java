package com.cognizant.truyum.dao;

import com.cognizant.truyum.model.*;
import java.util.*;

public class CartDaoSqlImplTest {

	public static void main(String[] args) {
		testGetAllCartItems();
		testAddCartItem();
		testRemoveCartItem();
	}
	
	public static void testAddCartItem(){
		CartDaoSqlImpl cc=new CartDaoSqlImpl();
		cc.addCartItem(11, 3);
		cc.addCartItem(11, 4);
		testGetAllCartItems();
		
	}

	public static void testGetAllCartItems(){
		CartDaoSqlImpl cc=new CartDaoSqlImpl();
		List<MenuItem> l=new ArrayList<>();
		l=cc.getAllCartItems((long)11);
		for(MenuItem i:l)
			System.out.println(i);
		System.out.println();
		
	}

	public static void testRemoveCartItem(){
		CartDaoSqlImpl cc=new CartDaoSqlImpl();
		cc.removeCartItem(11, 4);
		testGetAllCartItems();
	}
}
