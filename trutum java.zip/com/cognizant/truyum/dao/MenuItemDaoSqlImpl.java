package com.cognizant.truyum.dao;

import java.sql.*;
import java.util.*;
import com.cognizant.truyum.model.*;

public class MenuItemDaoSqlImpl {
	public static boolean check(String s){
		if(s.equals("Yes"))
			return true;
		return false;
	}

	public List<MenuItem> getMenuItemListAdmin(){
		try{
			Connection con=ConnectionHandler.getConnection();
			List<MenuItem> l=new ArrayList<MenuItem>();
			String selectMenuAdmin="SELECT * FROM menu_item";
			PreparedStatement ps=con.prepareStatement(selectMenuAdmin);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				MenuItem m=new MenuItem(rs.getLong(1),rs.getString(2),rs.getFloat(3), check(rs.getString(4)),rs.getDate(5),rs.getString(6),check(rs.getString(7)));
				l.add(m);
			}
			return l;
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public List<MenuItem> getMenuItemListCustomer(){
		try{
			Connection con=ConnectionHandler.getConnection();
			List<MenuItem> l=new ArrayList<MenuItem>();
			String selectMenuAdmin="SELECT * FROM menu_item where me_date_of_launch<CURDATE() and me_active=\"Yes\"";
			PreparedStatement ps=con.prepareStatement(selectMenuAdmin);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				MenuItem m=new MenuItem(rs.getLong(1),rs.getString(2),rs.getFloat(3), check(rs.getString(4)),rs.getDate(5),rs.getString(6),check(rs.getString(7)));
				l.add(m);
			}
			return l;
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}

	public MenuItem getMenuItem(long menuItemId){
		try{
			Connection con=ConnectionHandler.getConnection();
			String selectMenuAdmin="SELECT * FROM menu_item where me_id=?";
			PreparedStatement ps=con.prepareStatement(selectMenuAdmin);
			ps.setInt(1, (int)menuItemId);
			ResultSet rs=ps.executeQuery();
			rs.next();
			MenuItem m=new MenuItem(rs.getLong(1),rs.getString(2),rs.getFloat(3), check(rs.getString(4)),rs.getDate(5),rs.getString(6),check(rs.getString(7)));
			return m;
		}
		catch(Exception e){
			System.out.println("Item Not Found");
			return null;
		}		
	}
	
	public void editMenuItem(MenuItem menuItem){
		try{
			Connection con=ConnectionHandler.getConnection();
			String selectMenuAdmin="update menu_item set me_name=?,me_price=?,me_active=?,me_date_of_launch=?,me_category=?,me_free_delivery=? where me_id=?";
			PreparedStatement ps=con.prepareStatement(selectMenuAdmin);
			ps.setString(1, menuItem.getName());
			ps.setFloat(2, menuItem.getPrice());
			ps.setString(3, (menuItem.isActive())? "Yes": "No" );
			
			long l=menuItem.getDateOfLaunch().getTime();
			ps.setDate(4, new java.sql.Date(l));
			ps.setString(5, menuItem.getCategory());
			ps.setString(6, (menuItem.isFreeDelivery())?"Yes":"No");
			ps.setInt(7, (int)menuItem.getId());		
					
			ps.executeUpdate();
		}
		catch(Exception e){
			e.printStackTrace();
		}		
	}
	
	
}
