package com.cognizant.truyum.dao;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.truyum.model.*;


public class MenuItemDaoSqlImplTest {

	public static void main(String[] args) {
		testGetMenuItemListAdmin();
		testGetMenuItemListCustomer();
		testGetMenuItem();
		testModifyMenuItem();
	}
	
	public static void testGetMenuItemListAdmin(){
		MenuItemDaoSqlImpl s=new MenuItemDaoSqlImpl();
		List<MenuItem> l=new ArrayList<MenuItem>();
		l=s.getMenuItemListAdmin();
		for(MenuItem i:l)
			System.out.println(i);
		System.out.println();		
	}

	public static void testGetMenuItemListCustomer(){
		MenuItemDaoSqlImpl s=new MenuItemDaoSqlImpl();
		List<MenuItem> l=new ArrayList<MenuItem>();
		l=s.getMenuItemListCustomer();
		for(MenuItem i:l)
			System.out.println(i);
		System.out.println();		
	}

	public static void testGetMenuItem(){
		MenuItemDaoSqlImpl s=new MenuItemDaoSqlImpl();
		MenuItem m=s.getMenuItem((long)4);		
		System.out.println(m);		
		System.out.println();				
	}
	
	public static void testModifyMenuItem(){
		MenuItemDaoSqlImpl s=new MenuItemDaoSqlImpl();
		MenuItem m=s.getMenuItem((long)4);			
		m.setName("French Fries");		
		s.editMenuItem(m);
		testGetMenuItemListAdmin();
	}
	


}
