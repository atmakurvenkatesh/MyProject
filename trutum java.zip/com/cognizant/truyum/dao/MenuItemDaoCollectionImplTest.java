package com.cognizant.truyum.dao;

import java.util.*;
import com.cognizant.truyum.model.*;

public class MenuItemDaoCollectionImplTest {

	public static void main(String[] args) {
		testGetMenuItemListAdmin();
		testGetMenuItemListCustomer();
		testModifyMenuItem();
		
	}

	public static void testGetMenuItemListAdmin(){
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
		List<MenuItem> l=menuItemDao.getMenuItemListAdmin();
		for(MenuItem i:l){
			System.out.println(i.getId()+" "+i.getName()+" "+i.getPrice()+" "+i.isActive()+" "+i.getDateOfLaunch()+" "+i.getCategory()+" "+i.isFreeDelivery());
		}	
		System.out.println();
	}
	
	public static void testGetMenuItemListCustomer(){
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
		List<MenuItem> l1=menuItemDao.getMenuItemListCustomer();
		for(MenuItem i:l1){
			System.out.println(i.getId()+" "+i.getName()+" "+i.getPrice()+" "+i.isActive()+" "+i.getDateOfLaunch()+" "+i.getCategory()+" "+i.isFreeDelivery());
		}		
		System.out.println();
	}
	
	public static void testModifyMenuItem(){
		MenuItem mi;
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
		mi=menuItemDao.getMenuItem(1);
		mi.setName("BurgerBurger");
		menuItemDao.modifyMenuItem(mi);
		menuItemDao.getMenuItem(mi.getId());
		
	}
	
	
}
