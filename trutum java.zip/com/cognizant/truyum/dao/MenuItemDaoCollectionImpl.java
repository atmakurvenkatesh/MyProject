package com.cognizant.truyum.dao;

import java.util.*;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImpl implements MenuItemDao {
	private static List<MenuItem>  menuItemList;
	private static List<MenuItem> customerItems=new ArrayList<MenuItem>();
	
	public MenuItemDaoCollectionImpl() {
		if(menuItemList==null){
			menuItemList= new ArrayList<MenuItem>();
			DateUtil d=new DateUtil();
			MenuItem m1=new MenuItem((long)1,"Sandwich",(float)99.00,true,d.convertToDate("15/03/2017"),"Main Course",true);
			MenuItem m2=new MenuItem((long)2,"Burger",(float)129.00,true,d.convertToDate("23/12/2017"),"Main Course",false);
			MenuItem m3=new MenuItem((long)3,"Pizza",(float)149.00,true,d.convertToDate("21/08/2018"),"Main Course",false);
			MenuItem m4=new MenuItem((long)4,"French Fries",(float)57.00,false,d.convertToDate("02/07/2017"),"Staters",true);
			MenuItem m5=new MenuItem((long)5,"Chocolate Brownioe",(float)32.00,true,d.convertToDate("02/11/2022"),"Dessert",true);
	
			menuItemList.add(m1);
			menuItemList.add(m2);
			menuItemList.add(m3);
			menuItemList.add(m4);
			menuItemList.add(m5);
		}
	}	
	
	public List<MenuItem> getMenuItemListAdmin(){
		
		return menuItemList;
	}
	
	public List<MenuItem> getMenuItemListCustomer(){
		Date presentDate=new Date();
		for(MenuItem i:menuItemList){
			Date d=i.getDateOfLaunch();
			if(i.isActive() && d.before(presentDate) ){
				customerItems.add(i);
			}	
		}
		return customerItems;
	}
	
	public void modifyMenuItem(MenuItem menuItem){
		for(MenuItem i:menuItemList){
			if(i.getId() == menuItem.getId()){
				//i.setId(menuItem.getId());
				i.setName(menuItem.getName());
				i.setPrice(menuItem.getPrice());
				i.setActive(menuItem.isActive());
				i.setDateOfLaunch(menuItem.getDateOfLaunch());
				i.setCategory(menuItem.getCategory());
				i.setFreeDelivery(menuItem.isFreeDelivery());
				System.out.println(i);
			}
		}
	}
	
	public MenuItem getMenuItem(long menuItemId){
		for(MenuItem i:menuItemList){
			if(i.getId()==menuItemId){
				return i;
			}
		}
	return null;
	}


}

