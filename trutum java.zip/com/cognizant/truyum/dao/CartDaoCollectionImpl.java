package com.cognizant.truyum.dao;

import com.cognizant.truyum.model.*;
import java.util.*;

public class CartDaoCollectionImpl implements CartDao{
	private Map<Long,Cart> userCarts;

	public CartDaoCollectionImpl() {
		if(userCarts==null){
			userCarts=new HashMap<Long,Cart>();
		}
	}
	
	public void addCartItem(long userId,long menuItemId){
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
		MenuItem mi=menuItemDao.getMenuItem(menuItemId);
		double amount=mi.getPrice();
		if(userCarts.containsKey(userId)){
			Cart c=userCarts.get(userId);
			List<MenuItem> m=c.getMenuItemList();
			c.setTotal( amount + c.getTotal() );
			m.add(mi);
			c.setMenuItemList(m);
			userCarts.put(userId, c);
		}
		else{
			List<MenuItem> l=new ArrayList<MenuItem>();
			l.add(mi);
			Cart c=new Cart(l,amount);
			userCarts.put(userId,c);
			
		}
	}

	public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException{
		List<MenuItem> m=null;
		
		if(!userCarts.containsKey(userId)){			
			throw new CartEmptyException();
		}
		else{
			Cart c=userCarts.get(userId);
			m=c.getMenuItemList();
			if(m.isEmpty())
				throw new CartEmptyException();
			System.out.println("Total:"+c.getTotal());
			
			
		}
		return m;
	}

	public void removeCartItem(long userId,long menuItemId){
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
		MenuItem mi=menuItemDao.getMenuItem(menuItemId);
		if(userCarts.containsKey(userId)){
			Cart c=userCarts.get(userId);
			List<MenuItem> l=new ArrayList<MenuItem>();
			l=c.getMenuItemList();
			if(l.contains(mi)){
				l.remove(mi);
				float price=mi.getPrice();
				c.setTotal(c.getTotal()-price);
				c.setMenuItemList(l);
				userCarts.put(userId, c);
			}
		}
	}
	
}