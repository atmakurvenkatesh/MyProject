package com.cognizant.truyum.dao;

import java.sql.*;
import java.io.*;


public class ConnectionHandler {
	public static Connection getConnection(){
		try{
			BufferedReader br=new BufferedReader(new FileReader("C:/Users/839381/truYum/src/connection_properties.txt"));
			String s1[]=br.readLine().split("=");
			String s2[]=br.readLine().split("=");
			String s3[]=br.readLine().split("=");
			br.close();
			Connection con=DriverManager.getConnection(s1[1], s2[1], s3[1]);
			return con;
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}

	

}
