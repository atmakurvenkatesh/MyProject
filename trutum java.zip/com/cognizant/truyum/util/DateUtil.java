package com.cognizant.truyum.util;

import java.util.*;
import java.text.*;

public class DateUtil {
	public  Date convertToDate(String date){
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		try{
			return sdf.parse(date);
		}catch(ParseException e){
			e.printStackTrace();
			return null;
		}
	}

}
